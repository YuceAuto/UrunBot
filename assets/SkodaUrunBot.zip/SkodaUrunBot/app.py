from flask import Flask, request, render_template, jsonify
import openai
import os
import PyPDF2

# OpenAI API anahtarını ortam değişkeninden al
openai.api_key = os.getenv("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")

app = Flask(__name__)

def get_text_from_txt(file_path: str) -> str:
    """
    Bir TXT dosyasını okuyarak içeriğini döndürür.
    """
    with open(file_path, "r", encoding="utf-8") as file:
        return file.read()

def get_text_from_pdf(file_path: str) -> str:
    """
    Bir PDF dosyasını okuyarak içeriğini metin olarak döndürür.
    """
    extracted_text = ""
    with open(file_path, "rb") as file:
        pdf_reader = PyPDF2.PdfReader(file)
        for page in pdf_reader.pages:
            extracted_text += page.extract_text() + "\n"
    return extracted_text

def get_combined_content(folder_path: str) -> str:
    """
    Belirtilen klasördeki tüm PDF ve TXT dosyalarını okuyarak içeriği birleştirir.
    
    Parameters:
        - folder_path: PDF ve TXT dosyalarının bulunduğu klasörün yolu
    
    Returns:
        - combined_content: Birleştirilmiş metin içeriği
    """
    combined_content = ""
    for file_name in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file_name)
        if file_name.endswith(".txt"):
            combined_content += get_text_from_txt(file_path) + "\n\n"
        elif file_name.endswith(".pdf"):
            combined_content += get_text_from_pdf(file_path) + "\n\n"
        else:
            continue  # TXT ve PDF dışındaki dosyaları atla
    return combined_content

def get_answer_from_gpt4(prompt: str, folder_path: str) -> str:
    """
    Kullanıcıdan gelen soruya hem PDF hem de TXT dosyalarından alınan bağlamı ekleyerek GPT-4 API'den yanıt alır.
    
    Parameters:
        - prompt: Kullanıcının sorduğu soru
        - folder_path: PDF ve TXT dosyalarının bulunduğu klasörün yolu
    
    Returns:
        - Yanıt: GPT-4 API'den alınan yanıt
    """
    try:
        # PDF ve TXT dosyalarından bağlamı birleştir
        context = get_combined_content(folder_path)

        # OpenAI GPT-4 API'ye istek gönderme
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",  # Doğru model adını kullan
            messages=[
                {"role": "system", "content": "Aşağıdaki bağlamı kullanarak soruları yanıtla: " + context},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7
        )
        return response['choices'][0]['message']['content']
    except openai.error.AuthenticationError:
        return "API anahtarı geçersiz veya eksik. Lütfen doğru bir API anahtarı sağlayın."
    except openai.error.RateLimitError:
        return "API kullanım kotasını aştınız. Lütfen faturalandırma bilgilerinizi kontrol edin."
    except Exception as e:
        return f"Hata oluştu: {str(e)}"

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        prompt = request.form.get("prompt")
        folder_path = "docs"  # PDF ve TXT dosyalarının bulunduğu klasör
        if not os.path.exists(folder_path):
            return render_template("index.html", prompt=prompt, answer="Klasör bulunamadı.")
        answer = get_answer_from_gpt4(prompt, folder_path)
        return render_template("index.html", prompt=prompt, answer=answer)
    
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
